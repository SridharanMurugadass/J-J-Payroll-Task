## To run producer and consumer by docker-compose file
1. Change the value of config from appsettings.json which is in root folder
2. run following command 

docker-compose up  -- 1st time you can run this command it will build both image if not present
docker-compose up --build -- if any changes into dockerfile


### Create producer and consumer with docker build command

docker build -f Dockerfile.producer -t producer:1.0
docker build -f Dockerfile.consumer -t consumer:1.0

docker run -v ./appsettings.json:/src/Producer/com.anz.adaptor.config/appsetting.json producer:1.0  -- to run producer image


docker run -v ./appsettings.json:/src/Consumer/com.anz.adaptor.config/appsetting.json consumer:1.0  -- to run consumer image

#### Producer image ###
1. The producer image should configure with cron job so that it will run and check the file exist or not into nas drive
2. Once it find any new file it will process that file
