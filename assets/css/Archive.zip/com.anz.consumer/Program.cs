﻿using com.anz.adaptor.config;
using com.anz.adaptor.service;
using com.anz.adaptor.service.Interface;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Linq;
using System.Net;

namespace com.anz.consumer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Register services with the DI container
            var services = new ServiceCollection();
            services.AddSingleton<ILoggerService, LoggerService>();
            services.AddTransient<Kafka>();
            services.AddTransient<Convertor>();
            // Register FileManager service with the DI container and pass required dependencies
            services.AddTransient<FileManager>(serviceProvider =>
            {
                var loggerService = serviceProvider.GetRequiredService<ILoggerService>();
                var credential = new NetworkCredential(ConfigurationHelper.Get_nas_username(), ConfigurationHelper.Get_nas_username());

                return new FileManager(credential, loggerService);
            });

            // Build the service provider
            var serviceProvider = services.BuildServiceProvider();

            // Resolve services from the DI container
            var loggerService = serviceProvider.GetRequiredService<ILoggerService>();
            var kafka = serviceProvider.GetRequiredService<Kafka>();
            var convertor = serviceProvider.GetRequiredService<Convertor>();
            var fileManager = serviceProvider.GetRequiredService<FileManager>();

            string outputType = ConfigurationHelper.Get_output_file_type();
            string nasPath = ConfigurationHelper.Get_nas_path();
            string filesToBeCreatedAt = AppDomain.CurrentDomain.BaseDirectory + "//Created_Files//";
            string nasConsumerPath = nasPath + "//Consumer//";
            string nasLogPath = nasPath + "//logs//";

            loggerService.LogMessage($"Consumer Started");
            try
            {
                if (outputType != "json" && outputType != "csv")
                {
                    loggerService.LogError($"Output file format should either be csv or json. Kindly change the output_file_type in appsettings.json");
                    throw new Exception($"Output file format should either be csv or json. Kindly change the output_file_type in appsettings.json");
                }

                loggerService.LogMessage($"Consuming messages from kafka...");
                kafka.Consume(message =>
                {
                    // Convert message into json
                    var json = JObject.Parse(message);

                    // Extract fields from json
                    var fileName = json["FileName"]?.ToString() ?? "";
                    var fileData = json["FileData"]?.ToString() ?? "";

                    // Convert the fileData in csv format.
                    if (outputType == "csv")
                    {
                        loggerService.LogMessage("Converting the data in CSV...");
                        // get parse_by_line from json
                        bool parse_by_line = Convert.ToBoolean(json["parse_by_line"]?.ToString() ?? "false");

                        // Make the object as array of object
                        if (parse_by_line)
                        {
                            fileData = '[' + fileData + ']';
                        }

                        // Convert Json to CSV
                        fileData = convertor.ConvertToCsv(fileData);
                    }

                    // Build file name
                    var fileNameWithTS = $"{fileName}_{DateTime.Now:yyyy-MM-dd_HH-mm-ss-fff}";

                    // Create the file with data on local.
                    loggerService.LogMessage($"Creating the {fileNameWithTS}.{outputType} file at internal destination...");
                    bool isLocalFileCreated = fileManager.CreateFileOnLocal(fileNameWithTS, fileData, "." + outputType, filesToBeCreatedAt);

                    if (!isLocalFileCreated)
                    {
                        // If the local file is not created, there is no point in proceeding further.
                        loggerService.LogMessage(fileData);
                        loggerService.LogError($"Unable to create the file");
                        throw new Exception($"Unable to create the file. Consumed data is may be saved in log file.");
                    }

                    // Upload the local file to nas drive.
                    string localFilePath = Path.Combine(filesToBeCreatedAt, fileNameWithTS + "." + outputType);
                    loggerService.LogMessage($"Saving the file at {nasConsumerPath}...");
                    bool isLocalFileUploaded = fileManager.UploadLocalFileToNAS(localFilePath, nasConsumerPath);
                    if (!isLocalFileUploaded)
                    {
                        loggerService.LogError($"Unable to save the file at {nasConsumerPath}.Consumed data is saved at {filesToBeCreatedAt}.");
                    }

                    loggerService.LogMessage("Waiting for the new data from kafka...");
                });
            }
            catch (Exception ex)
            {
                loggerService.LogError(ex.ToString());
            }

            //TODO : The current implementation waits for new messages from Kafka indefinitely,
            //and only after an exception is thrown or the program is terminated, the logger service is disposed,
            //and the system log file is uploaded to NAS. Therefore, if there are no new messages from Kafka,
            //the log file will not be uploaded to NAS.

            //One way to solve this issue is to introduce a timeout in the Kafka consumer loop,
            //so that the consumer stops after a certain amount of time, even if no new messages are received.
            //Then, the logger service can be disposed, and the system log file can be uploaded to NAS.
            finally
            {
                // Close the logger. Pleae note an logs after this will not be logged in file. It will be logged only on console.
                // This is required to close and release the file.
                loggerService.Dispose();

                // Get the system log file path and upload it to NAS
                string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                string? systemLogFilePath = Directory.GetFiles(logDirectory, "log-*.txt")
                                            .OrderByDescending(f => new FileInfo(f).LastWriteTime)
                                            .FirstOrDefault();

                bool isSystemLogFileUploaded = fileManager.UploadLocalFileToNAS(systemLogFilePath, nasLogPath);
                if (!isSystemLogFileUploaded)
                {
                    loggerService.LogError($"Unable to move the system log file to ${nasLogPath}");
                }
            }
            Console.ReadLine();
        }
    }
}