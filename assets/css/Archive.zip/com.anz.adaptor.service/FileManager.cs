﻿using com.anz.adaptor.service.Interface;
using System.Net;

namespace com.anz.adaptor.service
{
    // This class provides methods for managing files, such as creating, uploading, downloading files and writing to a log file.
    public class FileManager
    {
        // These fields store the credentials and logger service to be used in file operations.
        private readonly NetworkCredential _credential;
        private readonly ILoggerService _loggerService;

        // This constructor initializes the credential and logger service fields.
        public FileManager(NetworkCredential credential, ILoggerService loggerService)
        {
            _loggerService = loggerService;
            _credential = credential;
        }

        // This method creates a file on the local machine with the specified filename, data, extension and folder path.
        public bool CreateFileOnLocal<T>(string filename, T filedata, string extension, string localFolderPath)
        {
            // Create the Consume_File folder if it doesn't exist
            if (!Directory.Exists(localFolderPath))
                Directory.CreateDirectory(localFolderPath);

            // Build the local file path
            var localFilePath = Path.Combine(localFolderPath, filename + extension);

            // Write the file data to the local file
            try
            {
                using (var writer = new StreamWriter(localFilePath))
                {
                    writer.Write(filedata);
                }
                _loggerService.LogMessage($"Successfully created local {filename}{extension} file at internal destination.");
                return true;
            }
            catch (Exception ex)
            {
                _loggerService.LogError($"An error occurred while writing the file locally: {ex.Message}");
                return false;
            }
        }

        // This method uploads a file from the local machine to a network-attached storage (NAS) location.
        public bool UploadLocalFileToNAS(string? localFilePath, string nasPath)
        {
            // Add a check for localFilePath; else return;
            if (localFilePath == null || !File.Exists(localFilePath))
            {
                _loggerService.LogError($"Unable to find the file at {localFilePath}.");
                return false;
            }

            // Get the filename and extention
            string fileNameWithExtention = Path.GetFileName(localFilePath);

            // TODO: This needs to be checked if we can create a direction on nas without creds
            // Create the _nasUrl folder if it doesn't exist
            if (!Directory.Exists(nasPath))
                Directory.CreateDirectory(nasPath);

            // Build the network file path
            var networkFilePath = Path.Combine(nasPath, fileNameWithExtention);

            // Upload the file to the network share
            try
            {
                using (var client = new WebClient())
                {
                    client.Credentials = _credential;
                    client.UploadFile(networkFilePath, localFilePath);
                }
                _loggerService.LogMessage($"Successfully uploaded {fileNameWithExtention} file at {nasPath}");
            }
            catch (Exception ex)
            {
                _loggerService.LogError($"Unable to save the file at {nasPath}.");
                _loggerService.LogError($"An error occurred while uploading the file to the network share: {ex.Message}");
                return false;
            }

            //TODO: Maybe move out this to separate function.
            // Delete the local file
            try
            {
                File.Delete(localFilePath);
            }
            catch (Exception ex)
            {
                _loggerService.LogError($"An error occurred while deleting the local file: {ex.Message}");
            }

            return true;
        }

        // This method downloads a file from a NAS location to the local machine.
        public bool DownloadNASFileToLocal(string nasFilePath, string destinationPath)
        {

            if (!Directory.Exists(destinationPath))
                Directory.CreateDirectory(destinationPath);

            // Get the filename and extention
            string fileNameWithExtention = Path.GetFileName(nasFilePath);

            // Build the destination file path
            var destinationFilePath = Path.Combine(destinationPath, fileNameWithExtention);

            try
            {
                using (WebClient client = new())
                {
                    client.Credentials = _credential;
                    client.DownloadFile(nasFilePath, destinationFilePath);
                }
                _loggerService.LogMessage($"Successfully downloaded {fileNameWithExtention} file at internal destination.");
                return true;
            }
            catch (Exception ex)
            {
                _loggerService.LogError($"Unable to download the file at {destinationPath}.");
                _loggerService.LogError($"An error occurred while downloading the file to the local path: {ex.Message}");
                return false;
            }

            //TODO: Is this check really required?
            //if (!File.Exists(destinationFilePath))
            //{
            //    _log.LogError($"Error while Downloading file {sourceFileName} to destination path");
            //    continue;
            //}
        }

        // This method creates a file on a NAS location.
        public bool CreateFileOnNas(string nasFilePath, string data)
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Credentials = _credential;

                    // Open a stream writer to the file on the UNC path.
                    using (StreamWriter writer = new StreamWriter(webClient.OpenWrite(nasFilePath)))
                    {
                        // Use the WriteLine method to write to a new line each time.
                        writer.WriteLine(data);
                    }
                }
                _loggerService.LogMessage("Successfully added the filename to the log File.");
                return true;
            }
            catch (Exception ex)
            {
                _loggerService.LogError($"Error writing filename to the log file: {ex.Message}");
                _loggerService.LogError($"Please note this file will process again on next run!!!");
                return false;
            }
        }
    }
}