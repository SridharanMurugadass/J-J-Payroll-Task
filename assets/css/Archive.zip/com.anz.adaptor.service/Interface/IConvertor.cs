﻿namespace com.anz.adaptor.service.Interface
{
    public interface IConvertor
    {
        string ConvertToCsv(string jsonData);

        List<string> ConvertToJson(string sourceFilePath, bool parseByLine);
    }
}
