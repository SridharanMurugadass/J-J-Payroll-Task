﻿using com.anz.adaptor.service.Interface;
using Serilog;
using Serilog.Events;

public class LoggerService : ILoggerService
{
    private ILogger _logger;

    public LoggerService()
    {
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
            .Enrich.FromLogContext()
            .WriteTo.Console()
            .WriteTo.File($"logs\\log-{DateTime.Now:yyyy-MM-dd-HH-mm-ss}.txt", rollingInterval: RollingInterval.Day)
            .CreateLogger();
        _logger = Log.Logger;
    }

    public void LogMessage(string message)
    {
        _logger.Information(message);
    }

    public void LogWarning(string message)
    {
        _logger.Warning(message);
    }

    public void LogError(string message)
    {
        _logger.Error(message);
    }

    // Dispose the logger when it is no longer needed
    public void Dispose()
    {
        Log.CloseAndFlush();
    }
}