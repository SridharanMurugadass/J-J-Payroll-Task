﻿using com.anz.adaptor.config;
using com.anz.adaptor.service.Interface;
using Confluent.Kafka;

namespace com.anz.adaptor.service
{
    public class Kafka
    {
        private readonly ILoggerService _loggerService;

        public Kafka(ILoggerService loggerService)
        {
            _loggerService = loggerService;
        }

        private static string topic_name = ConfigurationHelper.Get_topic_name();

        public async Task Produce(List<string> listData)
        {
            var config = new ProducerConfig
            {
                BootstrapServers = ConfigurationHelper.Get_bootstrap_servers(),
                SaslPassword = ConfigurationHelper.Get_sasl_password(),
                SaslUsername = ConfigurationHelper.Get_sasl_username(),
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
            };

            // If serializers are not specified, default serializers from
            // `Confluent.Kafka.Serializers` will be automatically used where
            // available. Note: by default strings are encoded as UTF8.
            using (var p = new ProducerBuilder<Null, string>(config).Build())
            {
                try
                {
                    foreach (var data in listData)
                    {
                        var dr = await p.ProduceAsync(topic_name, new Message<Null, string> { Value = data });
                        _loggerService.LogMessage($"Data Delivered to '{dr.TopicPartitionOffset}'");
                    }

                }
                catch (ProduceException<Null, string> e)
                {
                    _loggerService.LogError($"Delivery failed: {e.Error.Reason}");
                }
            }
        }

        public void Consume(Action<string> messageReceived)
        {
            var config = new ConsumerConfig
            {
                GroupId = "test-consumer-group",
                BootstrapServers = ConfigurationHelper.Get_bootstrap_servers(),
                SaslPassword = ConfigurationHelper.Get_sasl_password(),
                SaslUsername = ConfigurationHelper.Get_sasl_username(),
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                // Note: The AutoOffsetReset property determines the start offset in the event
                // there are not yet any committed offsets for the consumer group for the
                // topic/partitions of interest. By default, offsets are committed
                // automatically, so in this example, consumption will only start from the
                // earliest message in the topic 'my-topic' the first time you run the program.
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            using (var consumer = new ConsumerBuilder<Ignore, string>(config).Build())
            {
                consumer.Subscribe(topic_name);

                CancellationTokenSource cts = new CancellationTokenSource();
                Console.CancelKeyPress += (_, e) =>
                {
                    e.Cancel = true;
                    cts.Cancel();
                };

                try
                {
                    while (true)
                    {
                        try
                        {
                            var message = consumer.Consume(cts.Token);
                            _loggerService.LogMessage($"Data Consumed at: '{message.TopicPartitionOffset}'.");
                            messageReceived(message.Message.Value);
                        }
                        catch (ConsumeException e)
                        {
                            _loggerService.LogError($"Error occured: {e.Error.Reason}");
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    consumer.Close();
                }
            }
        }

    }
}
