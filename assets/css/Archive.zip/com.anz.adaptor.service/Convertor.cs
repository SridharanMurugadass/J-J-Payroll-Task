﻿using com.anz.adaptor.config;
using com.anz.adaptor.service.Interface;
using CsvHelper;
using Newtonsoft.Json;
using System.Collections.Specialized;
using System.Data;
using System.Globalization;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace com.anz.adaptor.service
{
    public class Convertor : IConvertor
    {

        public string ConvertToCsv(string jsonData)
        {
            var dt = JsonConvert.DeserializeObject<DataTable>(jsonData);
            using (var writer = new StringWriter())
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                foreach (DataColumn column in dt.Columns)
                {
                    csv.WriteField(column.ColumnName);
                }
                csv.NextRecord();

                foreach (DataRow row in dt.Rows)
                {
                    for (var i = 0; i < dt.Columns.Count; i++)
                    {
                        csv.WriteField(row[i]);
                    }
                    csv.NextRecord();
                }
                return writer.ToString();
            }
        }
        
        public List<string> ConvertToJson(string sourceFilePath, bool parseByLine)
        {
            List<Dictionary<string, string>> keyValuePairs = GetJsonObject(sourceFilePath);

            ListDictionary fileMetaData = GetFileMetaData(sourceFilePath);

            List<string> jsonData = new List<string>();

            if (parseByLine)
            {
                foreach (var keyValue in keyValuePairs)
                {
                    fileMetaData.Add("FileData", keyValue);
                    jsonData.Add(Serialize(fileMetaData));
                    fileMetaData.Remove("FileData");
                }
            }
            else
            {
                fileMetaData.Add("FileData", keyValuePairs);
                jsonData.Add(Serialize(fileMetaData));
            }

            return jsonData;
        }
        private static string Serialize<T>(T item) => System.Text.Json.JsonSerializer.Serialize(item, new JsonSerializerOptions
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });
        private List<Dictionary<string, string>> GetJsonObject(string filePath)
        {
            var csv = new List<string[]>();
            var lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
                csv.Add(line.Split(','));

            var properties = lines[0].Replace("\"", "").Split(',');

            var listObjResult = new List<Dictionary<string, string>>();

            for (int i = 1; i < lines.Length; i++)
            {
                var objResult = new Dictionary<string, string>();
                for (int j = 0; j < properties.Length; j++)
                    objResult.Add(properties[j], csv[i][j].Replace("\"", ""));

                listObjResult.Add(objResult);
            }

            return listObjResult;
        }
        private ListDictionary GetFileMetaData(string filePath)
        {
            ListDictionary fileMetaData = new()
            {
                { "FileName", Path.GetFileNameWithoutExtension(filePath) },
                { "Extension", Path.GetExtension(filePath) },
                { "parse_by_line", ConfigurationHelper.Get_parse_by_line()}
            };

            return fileMetaData;
        }

    }
}
