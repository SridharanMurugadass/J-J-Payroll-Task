﻿using com.anz.adaptor.config;
using com.anz.adaptor.service;
using com.anz.adaptor.service.Interface;
using Microsoft.Extensions.DependencyInjection;
using System.Net;

namespace com.anz.producer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Register services with the DI container
            var services = new ServiceCollection();
            services.AddSingleton<ILoggerService, LoggerService>();
            services.AddTransient<Kafka>();
            services.AddTransient<Convertor>();
            // Register FileManager service with the DI container and pass required dependencies
            services.AddTransient<FileManager>(serviceProvider =>
            {
                var loggerService = serviceProvider.GetRequiredService<ILoggerService>();
                var credential = new NetworkCredential(ConfigurationHelper.Get_nas_username(), ConfigurationHelper.Get_nas_username());

                return new FileManager(credential, loggerService);
            });

            // Build the service provider
            var serviceProvider = services.BuildServiceProvider();

            // Resolve services from the DI container
            var loggerService = serviceProvider.GetRequiredService<ILoggerService>();
            var kafka = serviceProvider.GetRequiredService<Kafka>();
            var convertor = serviceProvider.GetRequiredService<Convertor>();
            var fileManager = serviceProvider.GetRequiredService<FileManager>();

            // Set file paths and other configurations
            string filesToBeCreatedAt = AppDomain.CurrentDomain.BaseDirectory + "//Created_Files//";
            string filesToBeDownloadedAt = AppDomain.CurrentDomain.BaseDirectory + "//Downloaded_Files//";
            string fileToBeLoggedAt = AppDomain.CurrentDomain.BaseDirectory + "//Logs//";
            bool parseByLine = ConfigurationHelper.Get_parse_by_line();
            string nasPath = ConfigurationHelper.Get_nas_path();
            string logFileName = "processed_files_names";
            string logFileExtention = ".log";
            string logFileNameWithExtention = logFileName + logFileExtention;
            string nasLogPath = nasPath + "//logs//";
            string nasLogFilePath = nasLogPath + logFileNameWithExtention;

            loggerService.LogMessage($"Producer Started.");
            try
            {
                // Download the processed file log from the NAS and create one if it doesn't exist
                loggerService.LogMessage($"Downloading {logFileNameWithExtention} file at internal destination...");
                var isLogFileDownloaded = fileManager.DownloadNASFileToLocal(nasLogFilePath, fileToBeLoggedAt);
                if(!isLogFileDownloaded)
                {
                    loggerService.LogMessage($"Creating local {logFileNameWithExtention} file at internal destination...");
                    var isLogFileCreated = fileManager.CreateFileOnLocal(logFileName, String.Empty, logFileExtention, fileToBeLoggedAt);
                    if(!isLogFileCreated)
                    {
                        throw new Exception($"Unable to create local {logFileNameWithExtention}");
                    }
                }

                // Check if the log file exists and read its contents into a list
                string logFilePath = Path.Combine(fileToBeLoggedAt, logFileNameWithExtention);
                if (!File.Exists(logFilePath))
                {
                    throw new Exception($"{logFileNameWithExtention} file is not present at ${filesToBeCreatedAt}");
                }

                // Read the log file and store the filenames in a list
                List<string> processedFiles = new List<string>();
                string[] lines = File.ReadAllLines(logFilePath);
                processedFiles.AddRange(lines);

                // Process the files in the NAS directory that have not been processed already
                loggerService.LogMessage($"Processing of files is started...");
                foreach (string file in Directory.GetFiles(nasPath))
                {
                    string sourceFileNameWithExtension = Path.GetFileName(file);
                    string sourceFileExtention = Path.GetExtension(file);

                    // Skip files that have already been processed
                    if (processedFiles.Contains(file))
                    {
                        loggerService.LogWarning($"Sikiping {sourceFileNameWithExtension} since it is already processed.");
                        continue;
                    }

                    // Validate the file extension and skip files with invalid extension
                    if (sourceFileExtention.ToLower() != ".csv")
                    {
                        loggerService.LogWarning($"Invalid file extension. File name: {sourceFileNameWithExtension}");
                        continue;
                    }

                    // Download the file from NAS to local directory
                    loggerService.LogMessage($"Downloading {sourceFileNameWithExtension} file at internal destination path...");
                    var isFileDownloaded = fileManager.DownloadNASFileToLocal(file, filesToBeDownloadedAt);
                    if (!isFileDownloaded)
                    {
                        loggerService.LogError($"Error while Downloading file {sourceFileNameWithExtension} at internal destination path.");
                        continue;
                    }

                    // Convert the file data to JSON format
                    loggerService.LogMessage($"Converting {sourceFileNameWithExtension} file's Data into Json...");
                    string destinationFilePath = Path.Combine(filesToBeDownloadedAt, sourceFileNameWithExtension);
                    List<string> data = new();
                    data = convertor.ConvertToJson(destinationFilePath, parseByLine);

                    // Send the converted data to Kafka topic
                    loggerService.LogMessage("Sending converted Data to Kafka...");
                    try
                    {
                        kafka.Produce(data).Wait();
                    }
                    catch (Exception ex)
                    {
                        loggerService.LogError($"Error while Sending the data to Kafka. {ex.Message}");
                        continue;
                    }

                    // Log the processed file name to the processed logs file
                    loggerService.LogMessage("Writing the file name into processed logs...");
                    try
                    {
                        using (StreamWriter writer = File.AppendText(logFilePath))
                        {
                            writer.WriteLine(file);
                        }
                        loggerService.LogMessage("Successfully written the file name into processed logs.");
                    }
                    catch (Exception ex)
                    {
                        loggerService.LogError($"Unable to write the file name into processed logs. {ex.Message}");
                        loggerService.LogWarning($"{sourceFileNameWithExtension} is processed now and might be reprocessed in the next run."); //Warning
                    }
                }
                loggerService.LogMessage($"Processing of files is Completed.");

                // Upload the processed logs file to NAS
                loggerService.LogMessage($"Uploading the {logFileNameWithExtention} file to {nasLogPath}...");
                bool isLogFileUploaded = fileManager.UploadLocalFileToNAS(logFilePath, nasLogPath);
                if(!isLogFileUploaded)
                {
                    loggerService.LogError($"Unable to upload the {logFileNameWithExtention} file to ${nasLogPath}");
                    loggerService.LogWarning($"Files which are processed now might be reprocessed in the next run."); //Warning
                }

                loggerService.LogMessage($"Producer Finished.");
                
            }
            catch (Exception ex)
            {
                loggerService.LogError(ex.ToString());
            }
            finally
            {
                // Close the logger. Pleae note an logs after this will not be logged in file. It will be logged only on console.
                // This is required to close and release the file.
                loggerService.Dispose();

                // Get the system log file path and upload it to NAS
                string logDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                string? systemLogFilePath = Directory.GetFiles(logDirectory, "log-*.txt")
                    .OrderByDescending(f => new FileInfo(f).LastWriteTime)
                    .FirstOrDefault();

                bool isSystemLogFileUploaded = fileManager.UploadLocalFileToNAS(systemLogFilePath, nasLogPath);
                if (!isSystemLogFileUploaded)
                {
                    loggerService.LogError($"Unable to move the system log file to ${nasLogPath}");
                }
            }
            Console.ReadLine();
        }
    }
}