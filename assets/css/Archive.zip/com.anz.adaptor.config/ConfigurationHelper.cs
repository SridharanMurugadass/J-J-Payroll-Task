﻿using Microsoft.Extensions.Configuration;
using System.Reflection;

namespace com.anz.adaptor.config
{
    public static class ConfigurationHelper
    {
        private static string solutionDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.Parent.FullName;
        private static string appSettingsPath = Path.Combine(solutionDirectory, Assembly.GetExecutingAssembly().GetName().Name, "appsettings.json");
        private static readonly IConfiguration _configuration = new ConfigurationBuilder()
                .AddJsonFile(appSettingsPath)
                .Build();

        private static T GetValue<T>(string keyName)
        {
            if (_configuration == null)
            {
                throw new InvalidOperationException("The configuration is not available.");
            }

            var value = _configuration.GetValue<T>(keyName);

            if (value == null)
            {
                throw new InvalidOperationException($"The key {keyName} is not available in config.");
            }

            return value;
        }

        public static string Get_bootstrap_servers()
        {
            return GetValue<string>("bootstrap_servers");
        }

        public static string Get_sasl_password()
        {
            return GetValue<string>("sasl_password");
        }

        public static string Get_sasl_username()
        {
            return GetValue<string>("sasl_username");
        }

        public static string Get_topic_name()
        {
            return GetValue<string>("topic_name");
        }

        public static string Get_nas_path()
        {
            return GetValue<string>("nas_path");
        }
        
        public static string Get_nas_username()
        {
            return GetValue<string>("nas_username");
        }
        
        public static string Get_nas_password()
        {
            return GetValue<string>("nas_password");
        }

        public static bool Get_parse_by_line()
        {
            return GetValue<bool>("parse_by_line");
        }

        public static string Get_output_file_type()
        {
            return GetValue<string>("output_file_type");
        }
    }
}