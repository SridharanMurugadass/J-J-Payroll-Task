﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.anz.producer.helper
{
    internal static class ConfigurationHelper
    {
        private static readonly IConfiguration _configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

        private static T GetValue<T>(string keyName)
        {
            if (_configuration == null)
            {
                throw new InvalidOperationException("The configuration is not available.");
            }

            var value = _configuration.GetValue<T>(keyName);

            if(value == null)
            {
                throw new InvalidOperationException($"The key {keyName} is not available in config.");
            }

            return value;
        }

        public static string Get_bootstrap_servers()
        {
            return GetValue<string>("bootstrap_servers");
        }

        public static string Get_sasl_password()
        {
            return GetValue<string>("sasl_password");
        }

        public static string Get_sasl_username()
        {
            return GetValue<string>("sasl_username");
        }

        public static string Get_topic_name()
        {
            return GetValue<string>("topic_name");
        }
        public static string Get_nas_file_path()
        {
            return GetValue<string>("nas_file_path");
        }
        public static string Get_nas_username()
        {
            return GetValue<string>("nas_username");
        }
        public static string Get_nas_password()
        {
            return GetValue<string>("nas_password");
        }

        public static bool Get_parse_by_line()
        {
            return GetValue<bool>("parse_by_line");
        }
    }
}
