﻿using com.anz.producer.ANZ.api.messaging;
using com.anz.producer.ANZ.api.scripts;
using com.anz.producer.helper;
using com.anz.producer.Interface;
using System.Net;

namespace com.anz.producer
{
    public class Program
    {
        private static readonly ILog _log;

        static Program()
        {
            _log = new ConsoleLog();
        }
        public static void Main(string[] args)
        {
            //ToDo: Need to add last read file condition.

            _log.LogMessage($"Processing of file started");

            string destinationPath = AppDomain.CurrentDomain.BaseDirectory + "//Process_File//";
            string sourcePath = ConfigurationHelper.Get_nas_file_path();
            try
            {
                if (!Directory.Exists(destinationPath))
                    Directory.CreateDirectory(destinationPath);

                NetworkCredential credentials = new NetworkCredential(ConfigurationHelper.Get_nas_username(), ConfigurationHelper.Get_nas_password());

                foreach (string file in Directory.GetFiles(sourcePath))
                {
                    IConvertToJson? csvToJson = null;

                    string sourceFileName = Path.GetFileName(file);
                    string fileExtension =  Path.GetExtension(file);

                    string destinationFilePath = Path.Combine(destinationPath, sourceFileName);

                    switch (fileExtension.ToLower())
                    {
                        case ".csv":
                            csvToJson = new CsvJsonConverter();
                            break;

                        default:
                            _log.LogError($"Invalid file extension. File name: {file}");
                            break;
                    }

                    if (csvToJson == null)
                    {
                        continue;
                    }

                    _log.LogMessage($"Downloading file {sourceFileName} to destination path");

                    using (WebClient client = new())
                    {
                        client.Credentials = credentials;
                        client.DownloadFile(file, destinationFilePath);
                    }

                    if (!File.Exists(destinationFilePath))
                    {
                        _log.LogError($"Error while Downloading file {sourceFileName} to destination path");
                        continue;
                    }

                    _log.LogMessage("Converting Data to Json");

                    List<string> jsonRow = new();

                    if (ConfigurationHelper.Get_parse_by_line())
                        jsonRow = csvToJson.GetJsonForEachRows(destinationFilePath);
                    else
                        jsonRow.Add(csvToJson.GetJsonForFile(destinationFilePath));

                    _log.LogMessage("Sending Data to Kafka");

                    Kafka.SendData(jsonRow).Wait();
                }

                _log.LogMessage($"Processing of file Completed.");
            }
            catch (Exception ex)
            {
                _log.LogError(ex.ToString());
            }
            Console.ReadLine();
        }
    }
}