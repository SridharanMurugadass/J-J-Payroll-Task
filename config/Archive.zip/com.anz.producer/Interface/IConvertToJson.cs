﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.anz.producer.Interface
{
    internal interface IConvertToJson
    {
        string GetJsonForFile (string sourceFilePath);

        List<string> GetJsonForEachRows (string sourceFilePath);

        void ConvertToJson (string sourceFilePath, string destinationJsonFilePath);
    }
}
