﻿using com.anz.producer.helper;
using com.anz.producer.Interface;
using System.Collections.Specialized;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace com.anz.producer.ANZ.api.scripts
{
    internal class CsvJsonConverter : IConvertToJson
    {
        private static string Serialize<T>(T item) => JsonSerializer.Serialize(item, new JsonSerializerOptions
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });

        public string GetJsonForFile(string sourceFilePath)
        {
            var fileData = GetJsonObject(sourceFilePath);
            var fileMetaData = GetFileMetaData(sourceFilePath);

            fileMetaData.Add("FileData", fileData);
            return Serialize(fileMetaData);
        }

        public List<string> GetJsonForEachRows(string sourceFilePath)
        {
            List<Dictionary<string, string>> keyValuePairs = GetJsonObject(sourceFilePath);
            List<string> jsonPerRow = new List<string>();

            foreach (var keyValue in keyValuePairs)
            {
                var fileMetaData = GetFileMetaData(sourceFilePath);

                fileMetaData.Add("FileData", keyValue);

                jsonPerRow.Add(Serialize(fileMetaData));
            }

            return jsonPerRow;
        }

        public void ConvertToJson(string sourceFilePath, string destinationJsonFilePath)
        {
            string data = Serialize(GetJsonObject(sourceFilePath));

            File.WriteAllText(destinationJsonFilePath, data);
        }

        private List<Dictionary<string, string>> GetJsonObject(string filePath)
        {
            var csv = new List<string[]>();
            var lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
                csv.Add(line.Split(','));

            var properties = lines[0].Replace("\"", "").Split(',');

            var listObjResult = new List<Dictionary<string, string>>();

            for (int i = 1; i < lines.Length; i++)
            {
                var objResult = new Dictionary<string, string>();
                for (int j = 0; j < properties.Length; j++)
                    objResult.Add(properties[j], csv[i][j].Replace("\"", ""));

                listObjResult.Add(objResult);
            }

            return listObjResult;
        }

        private ListDictionary GetFileMetaData(string filePath)
        {
            ListDictionary fileMetaData = new()
            {
                { "FileName", Path.GetFileNameWithoutExtension(filePath) },
                { "Extension", Path.GetExtension(filePath) },
                { "parse_by_line", ConfigurationHelper.Get_parse_by_line()}
            };

            return fileMetaData;
        }
    }
}
