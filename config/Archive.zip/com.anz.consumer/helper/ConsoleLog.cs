﻿using com.anz.consumer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.anz.consumer.helper
{
    internal class ConsoleLog : ILog
    {
        public void LogMessage(string message)
        {
            Console.WriteLine($"Info ({DateTime.Now}): {message}");
        }

        public void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Error ({DateTime.Now}): {message}");
            Console.ResetColor();   
        }
    }
}
