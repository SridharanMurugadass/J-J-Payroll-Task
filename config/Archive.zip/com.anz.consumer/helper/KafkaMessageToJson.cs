﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace com.anz.consumer.helper
{
    public class KafkaMessageToJson
    {
        public static JObject ConvertToJson(string jsonData)
        {
            return JObject.Parse(jsonData);
        }

    }
}
