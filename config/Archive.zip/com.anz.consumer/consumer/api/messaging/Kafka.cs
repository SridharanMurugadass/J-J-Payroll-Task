﻿using com.anz.consumer.helper;
using com.anz.consumer.Interface;
using Confluent.Kafka;

namespace com.anz.consumer.ANZ.api.messaging
{
    internal class Kafka
    {
        private static readonly ILog _log;

        static Kafka()
        {
            _log = new ConsoleLog();
        }

        private static string topic_name = ConfigurationHelper.Get_topic_name();

        public void Consume(Action<string> messageReceived)
        {
            var config = new ConsumerConfig
            {
                GroupId = "test-consumer-group",
                BootstrapServers = ConfigurationHelper.Get_bootstrap_servers(),
                SaslPassword = ConfigurationHelper.Get_sasl_password(),
                SaslUsername = ConfigurationHelper.Get_sasl_username(),
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslMechanism = SaslMechanism.Plain,
                // Note: The AutoOffsetReset property determines the start offset in the event
                // there are not yet any committed offsets for the consumer group for the
                // topic/partitions of interest. By default, offsets are committed
                // automatically, so in this example, consumption will only start from the
                // earliest message in the topic 'my-topic' the first time you run the program.
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            using (var consumer = new ConsumerBuilder<Ignore, string>(config).Build())
            {
                consumer.Subscribe(topic_name);

                CancellationTokenSource cts = new CancellationTokenSource();
                Console.CancelKeyPress += (_, e) =>
                {
                    e.Cancel = true;
                    cts.Cancel();
                };

                try
                {
                    while (true)
                    {
                        try
                        {
                            var message = consumer.Consume(cts.Token);
                            _log.LogMessage($"Data Consumed at: '{message.TopicPartitionOffset}'.");
                            messageReceived(message.Message.Value);
                        }
                        catch (ConsumeException e)
                        {
                            _log.LogError($"Error occured: {e.Error.Reason}");
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    consumer.Close();
                }
            }
        }
    }
}

