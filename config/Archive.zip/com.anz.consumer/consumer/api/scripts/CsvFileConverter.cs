﻿using com.anz.consumer.Interface;
using CsvHelper;
using Newtonsoft.Json;
using System.Data;
using System.Globalization;

namespace com.anz.consumer.ANZ.api.scripts
{
    internal class CsvFileConverter : IConvertJSONToFile
    {
        public string ConvertToCsv(string jsonData)
        {
            var dt = JsonConvert.DeserializeObject<DataTable>(jsonData);
            using (var writer = new StringWriter())
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                foreach (DataColumn column in dt.Columns)
                {
                    csv.WriteField(column.ColumnName);
                }
                csv.NextRecord();

                foreach (DataRow row in dt.Rows)
                {
                    for (var i = 0; i < dt.Columns.Count; i++)
                    {
                        csv.WriteField(row[i]);
                    }
                    csv.NextRecord();
                }
                return writer.ToString();
            }
        }
    }
}
