﻿using com.anz.consumer.ANZ.api.messaging;
using com.anz.consumer.ANZ.api.scripts;
using com.anz.consumer.helper;
using com.anz.consumer.Interface;
using System.Net;

namespace com.anz.consumer
{
    public class Program
    {
        private static readonly ILog _log;

        static Program()
        {
            _log = new ConsoleLog();
        }
        public static void Main(string[] args)
        {
            //ToDo: Need to add last read file condition.

            _log.LogMessage($"Consuming messages from kafka");

            string destinationPath = AppDomain.CurrentDomain.BaseDirectory + "//Consume_File//";
            string nasDestPath = ConfigurationHelper.Get_nas_file_path();
            try
            {
                if (!Directory.Exists(destinationPath))
                    Directory.CreateDirectory(destinationPath);

                if (!Directory.Exists(nasDestPath))
                    Directory.CreateDirectory(nasDestPath);

                NetworkCredential credentials = new NetworkCredential(ConfigurationHelper.Get_nas_username(), ConfigurationHelper.Get_nas_password());

                var Kafka = new Kafka();
                IConvertJSONToFile? jsonToFile = null;

                Kafka.Consume(message =>
                {
                    var json = KafkaMessageToJson.ConvertToJson(message);
                    
                    var fileName = json["FileName"]?.ToString() ?? "";
                    var fileExtension = json["Extension"]?.ToString() ?? "";
                    var fileData = json["FileData"]?.ToString() ?? "";

                    switch (fileExtension.ToLower())
                    {
                        case ".csv":
                            jsonToFile = new CsvFileConverter();
                            break;

                        default:
                            _log.LogError($"Invalid file extension. File name: {fileName}");
                            break;
                    }
                    if (jsonToFile != null)
                    {
                        bool parse_by_line = Convert.ToBoolean(json["parse_by_line"]?.ToString() ?? "false");

                        if (parse_by_line)
                        {
                            fileData = '[' + fileData + ']';
                        }

                        string data = jsonToFile.ConvertToCsv(fileData);
                        var filePath = Path.Combine(destinationPath, fileName + fileExtension);

                        File.WriteAllText(filePath, data);


                        using (WebClient client = new())
                        {
                            _log.LogMessage($"Saving the file at {nasDestPath}...");
                            try
                            {
                                client.Credentials = credentials;
                                string nasCompletePath = $"{nasDestPath}//{fileName}_{DateTime.Now:yyyy-MM-dd_HH-mm-ss-fff}{fileExtension}";
                                client.UploadFile(nasCompletePath, filePath);
                                _log.LogMessage($"File successfuly saved at {nasCompletePath}");
                            }
                            catch (Exception ex){
                                _log.LogError($"Unable to save the file at {nasDestPath}. {ex.ToString()}");
                                _log.LogError(ex.ToString());
                            }
                        }
                    }                    
                });
            }
            catch (Exception ex)
            {
                _log.LogError(ex.ToString());
            }
            Console.ReadLine();
        }
    }
}